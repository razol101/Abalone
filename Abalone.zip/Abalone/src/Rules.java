import java.util.ArrayList;

public class Rules {
    public boolean isLegal(ArrayList<Marble> marbles_to_be_pushed, ArrayList<Marble> all_marbles, int row_to_be_pushed, int col_to_be_pushed) {
        return true;
    }
    private boolean less_in_front(ArrayList<Marble> marbles_to_be_pushed, ArrayList<Marble> all_marbles, int row_to_be_pushed, int col_to_be_pushed)
    {
    return true;
    }
}
