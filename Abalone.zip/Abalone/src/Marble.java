import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.NoSuchElementException;

public class Marble extends JLabel {

    public void setImageIcon(ImageIcon imageIcon) {
        this.imageIcon = imageIcon;
        setIcon(imageIcon);
    }

    public void setRow(int row) {
        this.row = row;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public void setColor(MarbleColor color) {
        this.color = color;
    }


    private ImageIcon imageIcon;
    private int row;
    private int col;


    private MarbleColor color;

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    private int weight;


    @Override
    public String toString() {
        return "Marble{" +
                "row=" + row +
                ", col=" + col +
                ", color=" + color +
                ", weight=" + weight +
                '}';
    }

    public Marble(ImageIcon imageIcon, int row, int col, MarbleColor color) {
        this.weight = 0;
        this.imageIcon = imageIcon;
        this.row = row;
        this.col = col;
        this.color = color;
        setIcon(imageIcon);

    }

    public Marble()
    {

    }
    public Marble(Marble m){
        this.col =m.col;
        this.row = m.row;
        this.color = m.color;
        this.imageIcon = m.imageIcon;
    }
    public MarbleColor getColor() {
        return color;
    }

    public ImageIcon getImageIcon() {
        return imageIcon;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public boolean equals(Marble other) {
        return other.getCol() == this.getCol() && other.getRow() == this.getRow() && other.getColor() == this.getColor() && other.getImageIcon() == this.getImageIcon();
    }

    public void setDirection(Directions direction) {
        if (color == MarbleColor.HINTED) {
            color.setDirection(direction);
        }
    }

    public Directions getDirection() {
        if (color.isHinted()) {
            return color.getDirection();
        }
        return null;
    }

    public boolean isNear(Marble other) {
        int rowDiff = Math.abs(this.row - other.row);
        int colDiff = Math.abs(this.col - other.col);


        Marble maxColMarble;
        Marble minColMarble;
        Marble maxRowMarble;
        Marble minRowMarble;
        if (this.getCol() >= other.getCol()) {
            maxColMarble = this;
            minColMarble = other;
        } else {
            maxColMarble = other;
            minColMarble = this;
        }

        if (this.getRow() >= other.getRow()) {
            maxRowMarble = this;
            minRowMarble = other;
        } else {
            maxRowMarble = other;
            minRowMarble = this;
        }
        if(this.getRow() < 4 || other.getRow() < 4){
            return (rowDiff == 1 && colDiff == 0) || // Vertical adjacency
                    (rowDiff == 0 && colDiff == 1) || // Horizontal adjacency
                    (maxRowMarble.equals(maxColMarble) && rowDiff == 1 && colDiff == 1);
        }
        else {
            return (rowDiff == 1 && colDiff == 0) || // Vertical adjacency
                    (rowDiff == 0 && colDiff == 1) || // Horizontal adjacency
                    (minRowMarble.equals(maxColMarble) && rowDiff == 1 && colDiff == 1);
        }
    }


}
