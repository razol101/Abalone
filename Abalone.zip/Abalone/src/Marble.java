import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.NoSuchElementException;

public class Marble extends JLabel {

    public void setImageIcon(ImageIcon imageIcon) {
        this.imageIcon = imageIcon;
        setIcon(imageIcon);
    }

    public void setRow(int row) {
        this.row = row;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public void setColor(MarbleColor color) {
        this.color = color;
    }


    private ImageIcon imageIcon;
    private int row;
    private int col;


    private MarbleColor color;


    public Marble(ImageIcon imageIcon, int row, int col, MarbleColor color) {
        this.imageIcon = imageIcon;
        this.row = row;
        this.col = col;
        this.color = color;
        setIcon(imageIcon);

    }

    public Marble()
    {

    }
    public Marble(Marble m){
        this.col =m.col;
        this.row = m.row;
        this.color = m.color;
        this.imageIcon = m.imageIcon;
    }
    public MarbleColor getColor() {
        return color;
    }

    public ImageIcon getImageIcon() {
        return imageIcon;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public boolean equals(Marble other) {
        return other.getCol() == this.getCol() && other.getRow() == this.getRow() && other.getColor() == this.getColor() && other.getImageIcon() == this.getImageIcon();
    }

    public void setDirection(Directions direction) {
        if (color == MarbleColor.HINTED) {
            color.setDirection(direction);
        }
    }

    public Directions getDirection() {
        if (color.isHinted()) {
            return color.getDirection();
        }
        return null;
    }

    public boolean isNear(Marble other) {
        int rowDiff = Math.abs(this.row - other.row);
        int colDiff = Math.abs(this.col - other.col);
        return (rowDiff == 1 && colDiff <= 1) || (colDiff == 1 && rowDiff == 0);
    }


}
