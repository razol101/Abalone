import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.NoSuchElementException;

public class Marble extends JLabel {

    public void setImageIcon(ImageIcon imageIcon) {
        this.imageIcon = imageIcon;
        setIcon(imageIcon);
    }

    public void setRow(int row) {
        this.row = row;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public void setColor(MarbleColor color) {
        this.color = color;
    }


    private ImageIcon imageIcon;
    private int row;
    private int col;


    private MarbleColor color;


    public Marble(ImageIcon imageIcon, int row, int col, MarbleColor color) {
        this.imageIcon = imageIcon;
        this.row = row;
        this.col = col;
        this.color = color;
        setIcon(imageIcon);

    }

    public Marble()
    {

    }
    public Marble(Marble m){
        this.col =m.col;
        this.row = m.row;
        this.color = m.color;
        this.imageIcon = m.imageIcon;
    }
    public MarbleColor getColor() {
        return color;
    }

    public ImageIcon getImageIcon() {
        return imageIcon;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public boolean equals(Marble other) {
        return other.getCol() == this.getCol() && other.getRow() == this.getRow() && other.getColor() == this.getColor() && other.getImageIcon() == this.getImageIcon();
    }

    public void setDirection(Directions direction) {
        if (color == MarbleColor.HINTED) {
            color.setDirection(direction);
        }
    }

    public Directions getDirection() {
        if (color.isHinted()) {
            return color.getDirection();
        }
        return null;
    }

    public boolean isNear(Marble other){
        ArrayList<Marble> arrayList = new ArrayList<>();
        arrayList.add(this);
        arrayList.add(other);
        Marble lower = arrayList.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
        Marble higher = arrayList.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
        return (Math.abs(other.getRow() - this.row) == 1 && higher.getCol() - lower.getCol() == -1) || (other.getRow() == this.row && Math.abs(other.getCol() - this.col) == 1) || (other.getCol() == this.col && Math.abs(other.getRow() - this.row) == 1);
    }

    public boolean isNearList(ArrayList<Marble> list){
        for (Marble marble: list) {
            if(!(this.isNear(marble)))
                return false;
        }
        return true;
    }

}
