import javax.swing.*;
import java.util.*;
import java.util.stream.Collectors;

public class Play {
    private int score;

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public ArrayList<Marble> getCurrent_marbles() {
        return current_marbles;
    }

    public void setCurrent_marbles(ArrayList<Marble> current_marbles) {
        this.current_marbles = current_marbles;
    }

    public ArrayList<Marble> getAfter_play_marbles() {
        return after_play_marbles;
    }

    public void setAfter_play_marbles(ArrayList<Marble> after_play_marbles) {
        this.after_play_marbles = after_play_marbles;
    }

    public Directions getDirection() {
        return direction;
    }

    public void setDirection(Directions direction) {
        this.direction = direction;
    }

    private ArrayList<Marble> current_marbles;
    private ArrayList<Marble> after_play_marbles;
    private ArrayList<Marble> marbles;
    private Directions direction;


    public Play(ArrayList<Marble> current_marbles, Directions direction, ArrayList<Marble> after_play_marbles, ArrayList<Marble> marbles) {
        this.current_marbles = new ArrayList<>(current_marbles);
        this.direction = direction;
        this.after_play_marbles = new ArrayList<>(after_play_marbles);
        this.marbles = new ArrayList<>(marbles);
        this.score = calculate_score();
    }

    public int calculate_score() {
        return calculate_new_score() - calculate_old_score();
    }

    private int calculate_old_score() {
        int sum = 0;
        for (Marble m : current_marbles) {
            sum += m.getWeight();
        }
        return sum;
    }

    private int calculate_new_score() {
        int sum = 0;

        if (canGetOut()) {
            sum += 7;
        }
        sum += 0.5 * update_score_after_move();
        for (Marble m : after_play_marbles) {
            sum += m.getWeight();
        }
        return sum;
    }

    private int update_score_after_move() {
        boolean allBrown = after_play_marbles.stream().allMatch(n -> n.getColor() == MarbleColor.BROWN);
        if (!allBrown) {
            for (Marble black : after_play_marbles) {
                if (black.getColor() == MarbleColor.BLACK) {
                    int sum = 1;
                    int size = 1;
                    if (direction == Directions.BOTTOM_RIGHT) {
                        sum += getBottomRight(black).getWeight();
                        if (getBottomRight(black).getColor() == MarbleColor.BLACK) {
                            sum += getBottomRight(getBottomRight(black)).getWeight();
                            size++;
                        }
                    } else if (direction == Directions.BOTTOM_LEFT) {
                        sum += getBottomLeft(black).getWeight();
                        if (getBottomLeft(black).getColor() == MarbleColor.BLACK) {
                            sum += getBottomLeft(getBottomLeft(black)).getWeight();
                            size++;
                        }
                    } else if (direction == Directions.TOP_LEFT) {
                        sum += getTopLeft(black).getWeight();
                        if (getTopLeft(black).getColor() == MarbleColor.BLACK) {
                            sum += getTopLeft(getTopLeft(black)).getWeight();
                            size++;
                        }
                    } else if (direction == Directions.TOP_RIGHT) {
                        sum += getTopRight(black).getWeight();
                        if (getTopRight(black).getColor() == MarbleColor.BLACK) {
                            sum += getTopRight(getTopRight(black)).getWeight();
                            size++;
                        }
                    } else if (direction == Directions.LEFT) {
                        sum += getLeft(black).getWeight();
                        if (getLeft(black).getColor() == MarbleColor.BLACK) {
                            sum += getLeft(getLeft(black)).getWeight();
                            size++;
                        }
                    } else if (direction == Directions.RIGHT) {
                        sum += getRight(black).getWeight();
                        if (getRight(black).getColor() == MarbleColor.BLACK) {
                            sum += getRight(getRight(black)).getWeight();
                            size++;
                        }
                    }
                    return (16 * size) / sum;
                }
            }
        }
        return 0;
    }

    private boolean canGetOut() {
        for (Marble marble :
                after_play_marbles) {
            if (marble.getWeight() == 0 && marble.getColor() == MarbleColor.BLACK) {
                if (direction == Directions.RIGHT) {
                    Marble right = current_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
                    return getRight(right).equals(marble) && getRight(getRight(right)).getCol() == 999;
                } else if (direction == Directions.LEFT) {
                    Marble left = current_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
                    return getLeft(left).equals(marble) && getLeft(getLeft(left)).getCol() == 999;
                } else if (direction == Directions.TOP_RIGHT) {
                    Marble TopRight = current_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                    return getTopRight(TopRight).equals(marble) && getTopRight(getTopRight(TopRight)).getCol() == 999;
                } else if (direction == Directions.TOP_LEFT) {
                    Marble TopLeft = current_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                    return getTopLeft(TopLeft).equals(marble) && getTopLeft(getTopLeft(TopLeft)).getCol() == 999;
                } else if (direction == Directions.BOTTOM_RIGHT) {
                    Marble BottomRight = current_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                    return getBottomRight(BottomRight).equals(marble) && getBottomRight(getBottomRight(BottomRight)).getCol() == 999;
                } else if (direction == Directions.BOTTOM_LEFT) {
                    Marble BottomLeft = current_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                    return getBottomLeft(BottomLeft).equals(marble) && getBottomLeft(getBottomLeft(BottomLeft)).getCol() == 999;
                }
            } else if (marble.getWeight() == 2 && marble.getColor() == MarbleColor.BLACK) {
                if (direction == Directions.RIGHT) {
                    Marble right = current_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
                    return getRight(right).equals(marble) && getRight(getRight(right)).getColor() == MarbleColor.BLACK && getRight(getRight(getRight(right))).getCol() == 999;
                } else if (direction == Directions.LEFT) {
                    Marble left = current_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
                    return getLeft(left).equals(marble) && getLeft(getLeft(left)).getColor() == MarbleColor.BLACK && getLeft(getLeft(getLeft(left))).getCol() == 999;
                } else if (direction == Directions.TOP_RIGHT) {
                    Marble TopRight = current_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                    return getTopRight(TopRight).equals(marble) && getTopRight(getTopRight(TopRight)).getColor() == MarbleColor.BLACK
                            && getTopRight(getTopRight(getTopRight(TopRight))).getCol() == 999;
                } else if (direction == Directions.TOP_LEFT) {
                    Marble TopLeft = current_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                    return getTopLeft(TopLeft).equals(marble) && getTopLeft(getTopLeft(TopLeft)).getColor() == MarbleColor.BLACK
                            && getTopLeft(getTopLeft(getTopLeft(TopLeft))).getCol() == 999;
                } else if (direction == Directions.BOTTOM_RIGHT) {
                    Marble BottomRight = current_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                    return getBottomRight(BottomRight).equals(marble) && getBottomRight(getBottomRight(BottomRight)).getColor() == MarbleColor.BLACK
                            && getBottomRight(getBottomRight(getBottomRight(BottomRight))).getCol() == 999;
                } else if (direction == Directions.BOTTOM_LEFT) {
                    Marble BottomLeft = current_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                    return getBottomLeft(BottomLeft).equals(marble) && getBottomLeft(getBottomLeft(BottomLeft)).getColor() == MarbleColor.BLACK
                            && getBottomLeft(getBottomLeft(getBottomLeft(BottomLeft))).getCol() == 999;
                }
            }
        }
        return false;
    }


    public Marble getRight(Marble marble) {
        for (Marble m : marbles) {
            if (m.getRow() == marble.getRow() && m.getCol() - 1 == marble.getCol())
                return m;
        }
        return new Marble(null, 999, 999, null);
    }

    public Marble getLeft(Marble marble) {
        for (Marble m : marbles) {
            if (m.getRow() == marble.getRow() && m.getCol() + 1 == marble.getCol())
                return m;
        }
        return new Marble(null, 999, 999, null);
    }

    public Marble getTopRight(Marble marble) {
        if (marble.getRow() > 4) {
            for (Marble m : marbles) {
                if (m.getRow() + 1 == marble.getRow() && m.getCol() - 1 == marble.getCol())
                    return m;
            }
        } else {
            for (Marble m : marbles)
                if (m.getRow() + 1 == marble.getRow() && m.getCol() == marble.getCol())
                    return m;
        }
        return new Marble(null, 999, 999, null);
    }

    public Marble getTopLeft(Marble marble) {
        if (marble.getRow() > 4) {
            for (Marble m : marbles)
                if (m.getRow() + 1 == marble.getRow() && m.getCol() == marble.getCol())
                    return m;
        } else
            for (Marble m : marbles)
                if (m.getRow() + 1 == marble.getRow() && m.getCol() + 1 == marble.getCol())
                    return m;

        return new Marble(null, 999, 999, null);
    }

    public Marble getBottomRight(Marble marble) {
        if (marble.getRow() >= 4) {
            for (Marble m : marbles) {
                if (m.getRow() - 1 == marble.getRow() && m.getCol() == marble.getCol())
                    return m;
            }
        } else {
            for (Marble m : marbles)
                if (m.getRow() - 1 == marble.getRow() && m.getCol() - 1 == marble.getCol())
                    return m;
        }
        return new Marble(null, 999, 999, null);
    }

    public Marble getBottomLeft(Marble marble) {
        if (marble.getRow() >= 4) {
            for (Marble m : marbles) {
                if (m.getRow() - 1 == marble.getRow() && m.getCol() + 1 == marble.getCol())
                    return m;
            }
        } else {
            for (Marble m : marbles)
                if (m.getRow() - 1 == marble.getRow() && m.getCol() == marble.getCol())
                    return m;
        }
        return new Marble(null, 999, 999, null);
    }
}

