import javax.swing.*;
import java.util.*;

public class Play {
    private int score;

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public ArrayList<Marble> getCurrent_marbles() {
        return current_marbles;
    }

    public void setCurrent_marbles(ArrayList<Marble> current_marbles) {
        this.current_marbles = current_marbles;
    }

    public ArrayList<Marble> getAfter_play_marbles() {
        return after_play_marbles;
    }

    public void setAfter_play_marbles(ArrayList<Marble> after_play_marbles) {
        this.after_play_marbles = after_play_marbles;
    }

    public Directions getDirection() {
        return direction;
    }

    public void setDirection(Directions direction) {
        this.direction = direction;
    }

    private ArrayList<Marble> current_marbles;
    private ArrayList<Marble> after_play_marbles;
    private Directions direction;


    public Play(ArrayList<Marble> current_marbles, Directions direction, ArrayList<Marble> after_play_marbles) {
        this.current_marbles = new ArrayList<>(current_marbles);
        this.direction = direction;
        this.after_play_marbles = new ArrayList<>(after_play_marbles);
        this.score = calculate_score();
    }

    public int calculate_score() {
        int sum = 0;
        Set<Marble> set = new HashSet<>(after_play_marbles);
        for (Marble m : set) {
            sum += m.getWeight();
        }
        return sum;
    }
}

