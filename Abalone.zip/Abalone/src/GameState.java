public enum GameState {

    CHOOSE, AVAILABLE, SELECTED, MOVE
}
