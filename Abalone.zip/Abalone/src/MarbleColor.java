public enum MarbleColor {
    BROWN, WHITE, BLACK, GREEN, HINTED;
    private Directions direction;
    MarbleColor(){
        this.direction = null;
    }
    public Directions getDirection() {
        return direction;
    }

    public void setDirection(Directions direction) {
        this.direction = direction;
    }

    public boolean isHinted() {
        return this == HINTED;
    }
}
