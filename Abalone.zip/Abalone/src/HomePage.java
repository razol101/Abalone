import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

public class HomePage extends JFrame {
    private JButton button1;

    public HomePage() {
        setTitle("Home Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 200);
        setLocationRelativeTo(null);

        // Create a panel with GridBagLayout
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(245, 245, 220)); // Set background color (light beige)

        // Add padding
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Create constraints for GridBagLayout
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(5, 5, 5, 5); // Add spacing

        // Add title label
        JLabel titleLabel = new JLabel("Welcome to Abalone!");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        panel.add(titleLabel, constraints);


        // Create buttons
        button1 = new JButton("Click Here To Start");

        // Customize button appearance
        button1.setBackground(new Color(139, 69, 19)); // Set background color (brown)
        button1.setForeground(Color.WHITE); // Set text color
        button1.setFont(new Font("Arial", Font.PLAIN, 16)); // Set font
        button1.setBorder(BorderFactory.createRaisedBevelBorder()); // Add border



        // Add buttons with spacing
        constraints.gridx = 1;
        constraints.gridy = 2; // Adjusted to position below titleLabel1
        constraints.gridwidth = 1;
        panel.add(button1, constraints);


        // Set action listeners for the buttons
        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Create and show the game board window for one player
                try {
                    new GameBoard().setVisible(true);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });


        // Add the panel to the frame
        getContentPane().add(panel);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new HomePage();
            }
        });
    }
}
