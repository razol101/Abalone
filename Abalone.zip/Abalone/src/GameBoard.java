import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;

public class GameBoard extends JFrame implements MouseListener {
    private final int numRows = 9; // Number of rows in the hexagon
    private final int numCols = 5; // Number of columns in the hexagon
    private final int circleDiameter = 50; // Diameter of each circle
    private final int circleSpacing = 20; // Spacing between circles
    private final Color backgroundColor = new Color(224, 206, 158); // Background color of the board
    private List<Marble> marbles;

    private ArrayList<Marble> chosen_marbles = new ArrayList<>();

    private GameState gameState = GameState.CHOOSE;
    private static int GreenCount = 0;

    public GameBoard() throws IOException {
        setTitle("Abalone Game Board");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 800);
        setLocationRelativeTo(null);

        setLayout(null);


        setLocationRelativeTo(null);

        marbles = new ArrayList<>();

        JPanel boardPanel = new JPanel();
        boardPanel.setLayout(null);
        boardPanel.setBackground(backgroundColor);
        boardPanel.setBounds(0, 0, 800, 800);

        File HoleIcon1 = new File("images/brown.png");
        BufferedImage originalImage = ImageIO.read(HoleIcon1);
        int resizedDiameter = circleDiameter;

        // Resize the image
        Image resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon HoleIcon = new ImageIcon(resizedImage);


        File white1 = new File("images/white.jpg");
        BufferedImage originalWhite = ImageIO.read(white1);
        int resizedDiameterColour = 50;

        // Resize the image
        Image resizedWhite = originalWhite.getScaledInstance(resizedDiameterColour, resizedDiameterColour, Image.SCALE_SMOOTH);
        ImageIcon White = new ImageIcon(resizedWhite);

        File black1 = new File("images/Black.png");
        BufferedImage originalBlack = ImageIO.read(black1);

        // Resize the image
        Image resizedBlack = originalBlack.getScaledInstance(resizedDiameterColour, resizedDiameterColour, Image.SCALE_SMOOTH);
        ImageIcon Black = new ImageIcon(resizedBlack);

        // Calculate the center of the panel
        int centerX = getWidth() / 2;
        int centerY = getHeight() / 2;
        drawBoard(centerX, centerY, White, Black, HoleIcon, boardPanel);
        add(boardPanel);
        setVisible(true);
    }

    private void drawBoard(int centerX, int centerY, ImageIcon White, ImageIcon Black, ImageIcon HoleIcon, JPanel boardPanel) {
        // Draw the hexagonal grid of spaces
        for (int row = 0; row < numRows; row++) {
            int numSpaces = 4 + numCols - Math.min(numCols - 1, Math.abs(row - numRows / 2));
            int y = centerY - ((numRows / 2 - row) * (circleDiameter + circleSpacing) + circleDiameter);
            int x = centerX - ((numSpaces - 1) * (circleDiameter + circleSpacing) / 2);
            for (int col = 0; col < numSpaces; col++) {
                if (row < 2 || (row == 2 && (col > 1 && col < 5))) {
                    Marble marble = new Marble(White, row, col, MarbleColor.WHITE);
                    marble.setBounds(x, y, White.getIconWidth(), White.getIconHeight());
                    marble.addMouseListener(this);
                    marbles.add(marble);
                    boardPanel.add(marble);
                    marble.setOpaque(false);
                    x += circleDiameter + circleSpacing;
                } else if (row > 6 || (row == 6 && (col > 1 && col < 5))) {
                    Marble marble = new Marble(Black, row, col, MarbleColor.BLACK);
                    marble.setBounds(x, y, Black.getIconWidth(), Black.getIconHeight());
                    marble.addMouseListener(this);
                    marbles.add(marble);
                    boardPanel.add(marble);
                    marble.setOpaque(false);
                    x += circleDiameter + circleSpacing;
                } else {
                    Marble marble = new Marble(HoleIcon, row, col, MarbleColor.BROWN);
                    marble.setBounds(x, y, HoleIcon.getIconWidth(), HoleIcon.getIconHeight());
                    marble.addMouseListener(this);
                    marbles.add(marble);
                    boardPanel.add(marble);
                    marble.setOpaque(false);
                    x += circleDiameter + circleSpacing;
                }
            }
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    GameBoard gameBoard = new GameBoard();
                    gameBoard.setVisible(true);

                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        Component component = getContentPane().getComponentAt(x, y);
        File Green1 = new File("images/green.png");
        BufferedImage originalImage = null;
        try {
            originalImage = ImageIO.read(Green1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        int resizedDiameter = circleDiameter;

        // Resize the image
        Image resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon Green = new ImageIcon(resizedImage);


        File black1 = new File("images/Black.png");
        BufferedImage originalBlack = null;
        try {
            originalBlack = ImageIO.read(black1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        Image resizedBlack = originalBlack.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon Black = new ImageIcon(resizedBlack);


        File Brown1 = new File("images/brown.png");
        try {
            originalImage = ImageIO.read(Brown1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon Brown = new ImageIcon(resizedImage);

        for (Marble marble : marbles) {
            if (e.getSource() == marble) {
                System.out.println("col: " + marble.getCol());
                System.out.println("row: " + marble.getRow());
                if (marble.getColor() == MarbleColor.BLACK) {
                    this.resetChosen(e, Black);
                    if (chosen_marbles.size() > 0) {
                        if (!checkMove(chosen_marbles, marble))
                            return;
                    }
                    marble.setImageIcon(Green);
                    marble.setColor(MarbleColor.GREEN);
                    chosen_marbles.add(marble);
                    System.out.println("Size:" + chosen_marbles.size());
                    GreenCount++;
                    System.out.println("Greens:" + GreenCount);

                } else if (marble.getColor() == MarbleColor.GREEN || marble.getColor() == MarbleColor.HINTED) {
                    for (Marble mar : chosen_marbles) {
                        mar.setImageIcon(Black);
                        mar.setColor(MarbleColor.BLACK);
                    }
                    GreenCount = 0;
                    chosen_marbles = new ArrayList<>();
                } else if (marble.getColor() == MarbleColor.BROWN) {
                    if (chosen_marbles.size() > 0) {
                        this.moveMarbles(Black, Brown);
                    }
                } else if (marble.getColor() == MarbleColor.WHITE) {

                }
            }
            gameState = GameState.SELECTED;
        }
    }

    private void resetChosen(MouseEvent e, ImageIcon Black) {
        if (GreenCount == 3) {
            for (Marble marble2 : chosen_marbles) {
                if ((marble2.getColor() == MarbleColor.GREEN || marble2.getColor() == MarbleColor.HINTED) && e.getSource() != marble2) {
                    marble2.setImageIcon(Black);
                    marble2.setColor(MarbleColor.BLACK);
                }
            }
            chosen_marbles = new ArrayList<>();
            GreenCount = 0;
        }
    }

    private boolean checkMove(ArrayList<Marble> pushed_marbles, Marble marble) {
        ArrayList<Marble> newSelection = new ArrayList<>(pushed_marbles);
        newSelection.add(marble);

        boolean inLine = isInLine(newSelection);
        boolean adjacent = isAdjacent(newSelection);

        return inLine && adjacent;
    }

    private boolean isInLine(ArrayList<Marble> marbles) {
        if (marbles.size() == 1) {
            return true;
        }

        int first_chosen_marble_row = marbles.get(0).getRow();
        int first_chosen_marble_col = marbles.get(0).getCol();

        boolean sameRow = true;
        boolean sameCol = true;
        boolean leftDiagonal = true;
        boolean rightDiagonal = true;

        for (Marble marble : marbles) {
            int row = marble.getRow();
            int col = marble.getCol();

            if (row != first_chosen_marble_row) {
                sameRow = false;
            }
            if (col != first_chosen_marble_col) {
                sameCol = false;
            }
            if (col != first_chosen_marble_col && first_chosen_marble_row != 3 && first_chosen_marble_row != 5 && row != 3 && row != 5) {
                sameCol = false;
            } else if (((first_chosen_marble_row == 3 && row == 5 && Math.abs(first_chosen_marble_col - col) == 1)
                    || (first_chosen_marble_row == 5 && row == 3 && Math.abs(first_chosen_marble_col - col) == 1))) {
                sameCol = true;
            }
            // Check left diagonal condition
            if ((first_chosen_marble_row - row) != (first_chosen_marble_col - col)) {
                leftDiagonal = false;
            }
            // Check right diagonal condition
            if ((row - first_chosen_marble_row) != (first_chosen_marble_col - col)) {
                rightDiagonal = false;
            }

            // If all are false, no need to check further
            if (!sameRow && !sameCol && !leftDiagonal && !rightDiagonal) {
                return false;
            }
        }

        return true;
    }

    private boolean isAdjacent(ArrayList<Marble> marbles) {
        for (Marble marble1 : marbles) {
            boolean foundAdjacent = false;
            for (Marble marble2 : marbles) {
                if (marble1 != marble2 && marble1.isNear(marble2)) {
                    foundAdjacent = true;
                    break;
                }
            }
            if (!foundAdjacent) {
                return false;
            }
        }
        return true;
    }

    private void moveMarbles(ImageIcon Black, ImageIcon Brown) {
        if (chosen_marbles.get(0).getDirection() == Directions.TOP_LEFT) {
            Marble minimum_marble_col = chosen_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
            Marble max_marble_col = chosen_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
            boolean canMoveTopLeftFirst = (minimum_marble_col.getCol() != max_marble_col.getCol() && minimum_marble_col.getRow() > 4 && max_marble_col.getRow() > 4);
            boolean canMoveTopLeftSecond = (minimum_marble_col.getCol() == max_marble_col.getCol() && minimum_marble_col.getRow() <= 4 && max_marble_col.getRow() <= 4);
            boolean canMoveTopLeftThird = (minimum_marble_col.getCol() != max_marble_col.getCol() && ((((minimum_marble_col.getRow() == 4))
                    || ((minimum_marble_col.getRow() > 4)))));
            boolean canMoveTopLeftForth = (max_marble_col.getCol() != minimum_marble_col.getCol() && minimum_marble_col.getRow() == max_marble_col.getRow());

            if (canMoveTopLeftFirst || canMoveTopLeftSecond || canMoveTopLeftThird || canMoveTopLeftForth) {
                for (Marble marble : chosen_marbles) {
                    getTopLeft(marble).setColor(MarbleColor.BLACK);
                    getTopLeft(marble).setImageIcon(Black);
                    marble.setImageIcon(Brown);
                    marble.setColor(MarbleColor.BROWN);
                }
            } else {
                minimum_marble_col = chosen_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                max_marble_col = chosen_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);

                getTopLeft(minimum_marble_col).setImageIcon(Black);
                getTopLeft(minimum_marble_col).setColor(MarbleColor.BLACK);
                for (Marble mar : chosen_marbles) {
                    mar.setColor(MarbleColor.BLACK);
                    mar.setImageIcon(Black);
                }
                max_marble_col.setColor(MarbleColor.BROWN);
                max_marble_col.setImageIcon(Brown);
            }
            chosen_marbles = new ArrayList<>();
            GreenCount = 0;
        }
        else if (chosen_marbles.get(0).getDirection() == Directions.TOP_RIGHT) {
            Marble min_marble_col = chosen_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
            Marble max_marble_col = chosen_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
            boolean canMoveTopLeftFirst = (min_marble_col.getCol() != max_marble_col.getCol() && min_marble_col.getRow() > 4 && max_marble_col.getRow() > 4 && min_marble_col.getRow() != max_marble_col.getRow());
            boolean canMoveTopLeftSecond = (min_marble_col.getCol() == max_marble_col.getCol() && min_marble_col.getRow() <= 4 && max_marble_col.getRow() <= 4);
            boolean canMoveTopLeftThird = (min_marble_col.getCol() != max_marble_col.getCol() && ((((min_marble_col.getRow() == 4) && max_marble_col.getRow() > 4))
                    || ((min_marble_col.getRow() > 4) && max_marble_col.getRow() == 4)));
//            boolean canMoveTopLeftForth = (max_marble_col.getCol() != min_marble_col.getCol() && min_marble_col.getRow() == max_marble_col.getRow());
            if (canMoveTopLeftFirst || canMoveTopLeftSecond || canMoveTopLeftThird) {
                min_marble_col = chosen_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                max_marble_col = chosen_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);

                getTopRight(min_marble_col).setImageIcon(Black);
                getTopRight(min_marble_col).setColor(MarbleColor.BLACK);
                for (Marble mar : chosen_marbles) {
                    mar.setColor(MarbleColor.BLACK);
                    mar.setImageIcon(Black);
                }
                max_marble_col.setColor(MarbleColor.BROWN);
                max_marble_col.setImageIcon(Brown);
            } else {
                for (Marble marble : chosen_marbles) {
                    getTopRight(marble).setColor(MarbleColor.BLACK);
                    getTopRight(marble).setImageIcon(Black);
                    marble.setImageIcon(Brown);
                    marble.setColor(MarbleColor.BROWN);
                }

            }
            chosen_marbles = new ArrayList<>();
            GreenCount = 0;
        }
        else if (chosen_marbles.get(0).getDirection() == Directions.LEFT) {
            Marble m = chosen_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            Marble m2 = chosen_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            if (m.getRow() != m2.getRow()) {
                for (Marble marble : chosen_marbles) {
                    getLeft(marble).setColor(MarbleColor.BLACK);
                    getLeft(marble).setImageIcon(Black);
                    marble.setImageIcon(Brown);
                    marble.setColor(MarbleColor.BROWN);
                }
            } else {
                m = chosen_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
                m2 = chosen_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
                getLeft(m).setImageIcon(Black);
                getLeft(m).setColor(MarbleColor.BLACK);
                for (Marble mar : chosen_marbles) {
                    mar.setColor(MarbleColor.BLACK);
                    mar.setImageIcon(Black);
                }
                m2.setColor(MarbleColor.BROWN);
                m2.setImageIcon(Brown);
            }
            chosen_marbles = new ArrayList<>();
            GreenCount = 0;

        }
        else if (chosen_marbles.get(0).getDirection() == Directions.RIGHT) {
            Marble m = chosen_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            Marble m2 = chosen_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            if (m.getRow() != m2.getRow()) {
                for (Marble marble : chosen_marbles) {
                    getRight(marble).setColor(MarbleColor.BLACK);
                    getRight(marble).setImageIcon(Black);
                    marble.setImageIcon(Brown);
                    marble.setColor(MarbleColor.BROWN);
                }
            } else {
                m = chosen_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
                m2 = chosen_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
                getRight(m2).setImageIcon(Black);
                getRight(m2).setColor(MarbleColor.BLACK);
                for (Marble mar : chosen_marbles) {
                    mar.setColor(MarbleColor.BLACK);
                    mar.setImageIcon(Black);
                }
                m.setColor(MarbleColor.BROWN);
                m.setImageIcon(Brown);
            }
            chosen_marbles = new ArrayList<>();
            GreenCount = 0;
        }
        else if (chosen_marbles.get(0).getDirection() == Directions.BOTTOM_RIGHT) {

            Marble min_marble_col = chosen_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
            Marble max_marble_col = chosen_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
            //boolean canMoveTopLeftFirst = (min_marble_col.getCol() == max_marble_col.getCol() && (min_marble_col.getRow() <= 4 || max_marble_col.getRow() <= 4));
            boolean canMoveTopLeftSecond = (min_marble_col.getCol() == max_marble_col.getCol() && min_marble_col.getRow() >= 4 && max_marble_col.getRow() >= 4);
//            boolean canMoveTopLeftThird = (min_marble_col.getCol() != max_marble_col.getCol() && ((((min_marble_col.getRow() == 4) && max_marble_col.getRow() > 4))
//                    || ((min_marble_col.getRow() > 4) && max_marble_col.getRow() == 4)));
            if ( canMoveTopLeftSecond) {
                min_marble_col = chosen_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                max_marble_col = chosen_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);

                getBottomRight(max_marble_col).setImageIcon(Black);
                getBottomRight(max_marble_col).setColor(MarbleColor.BLACK);
                for (Marble mar : chosen_marbles) {
                    mar.setColor(MarbleColor.BLACK);
                    mar.setImageIcon(Black);
                }
                min_marble_col.setColor(MarbleColor.BROWN);
                min_marble_col.setImageIcon(Brown);
            } else {
                for (Marble marble : chosen_marbles) {
                    getBottomRight(marble).setColor(MarbleColor.BLACK);
                    getBottomRight(marble).setImageIcon(Black);
                    marble.setImageIcon(Brown);
                    marble.setColor(MarbleColor.BROWN);
                }

            }
            chosen_marbles = new ArrayList<>();
            GreenCount = 0;
        }
        else if (chosen_marbles.get(0).getDirection() == Directions.BOTTOM_LEFT) {

            Marble min_marble_col = chosen_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
            Marble max_marble_col = chosen_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
            //boolean canMoveTopLeftFirst = (min_marble_col.getCol() == max_marble_col.getCol() && (min_marble_col.getRow() <= 4 || max_marble_col.getRow() <= 4));
            boolean canMoveTopLeftSecond = (min_marble_col.getCol() == max_marble_col.getCol() && min_marble_col.getRow() >= 4 && max_marble_col.getRow() >= 4);
//            boolean canMoveTopLeftThird = (min_marble_col.getCol() != max_marble_col.getCol() && ((((min_marble_col.getRow() == 4) && max_marble_col.getRow() > 4))
//                    || ((min_marble_col.getRow() > 4) && max_marble_col.getRow() == 4)));
            if ( canMoveTopLeftSecond) {
                min_marble_col = chosen_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                max_marble_col = chosen_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);

                getBottomRight(max_marble_col).setImageIcon(Black);
                getBottomRight(max_marble_col).setColor(MarbleColor.BLACK);
                for (Marble mar : chosen_marbles) {
                    mar.setColor(MarbleColor.BLACK);
                    mar.setImageIcon(Black);
                }
                min_marble_col.setColor(MarbleColor.BROWN);
                min_marble_col.setImageIcon(Brown);
            } else {
                for (Marble marble : chosen_marbles) {
                    getBottomRight(marble).setColor(MarbleColor.BLACK);
                    getBottomRight(marble).setImageIcon(Black);
                    marble.setImageIcon(Brown);
                    marble.setColor(MarbleColor.BROWN);
                }

            }
            chosen_marbles = new ArrayList<>();
            GreenCount = 0;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // put arrow on selected marbles

        BufferedImage originalImage = null;
        int resizedDiameter = circleDiameter;
        Image resizedImage = null;

        File ArrowTopRight1 = new File("images/arrowrightup.png");
        try {
            originalImage = ImageIO.read(ArrowTopRight1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon ArrowTopRight = new ImageIcon(resizedImage);

        File ArrowRight1 = new File("images/arrowright.png");
        try {
            originalImage = ImageIO.read(ArrowRight1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon ArrowRight = new ImageIcon(resizedImage);

        File ArrowBottomRight1 = new File("images/arrowrightdown.png");
        try {
            originalImage = ImageIO.read(ArrowBottomRight1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon ArrowBottomRight = new ImageIcon(resizedImage);

        File ArrowTopLeft1 = new File("images/arrowleftup.png");
        try {
            originalImage = ImageIO.read(ArrowTopLeft1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon ArrowTopLeft = new ImageIcon(resizedImage);

        File ArrowLeft1 = new File("images/arrowleft.png");
        try {
            originalImage = ImageIO.read(ArrowLeft1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon ArrowLeft = new ImageIcon(resizedImage);

        File ArrowBottomLeft1 = new File("images/arrowBottomLeft.png");
        try {
            originalImage = ImageIO.read(ArrowBottomLeft1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon ArrowBottomLeft = new ImageIcon(resizedImage);

        Marble selected = null;
        for (Marble m : marbles) {
            if (m == e.getSource())
                selected = new Marble(m);
        }

        for (Marble m : chosen_marbles) {
            assert selected != null;
            if (selected.getColor() != MarbleColor.BLACK && selected.getColor() != MarbleColor.GREEN && selected.getColor() != MarbleColor.HINTED) {

                if (canMoveTopRight(chosen_marbles, selected)) {
                    for (Marble m1 : chosen_marbles) {
                        m1.setImageIcon(ArrowTopRight);
                        m1.setColor(MarbleColor.HINTED);
                        m1.setDirection(Directions.TOP_RIGHT);

                    }
                } else if (canMoveTopLeft(chosen_marbles, selected)) {
                    for (Marble m1 : chosen_marbles) {
                        m1.setImageIcon(ArrowTopLeft);
                        m1.setColor(MarbleColor.HINTED);
                        m1.setDirection(Directions.TOP_LEFT);

                    }
                } else if (canMoveRight(chosen_marbles, selected)) {
                    for (Marble m1 : chosen_marbles) {
                        m1.setImageIcon(ArrowRight);
                        m1.setColor(MarbleColor.HINTED);
                        m1.setDirection(Directions.RIGHT);

                    }
                } else if (canMoveLeft(chosen_marbles, selected)) {
                    for (Marble m1 : chosen_marbles) {
                        m1.setImageIcon(ArrowLeft);
                        m1.setColor(MarbleColor.HINTED);
                        m1.setDirection(Directions.LEFT);

                    }
                } else if (canMoveBottomRight(chosen_marbles, selected)) {
                    for (Marble m1 : chosen_marbles) {
                        m1.setImageIcon(ArrowBottomRight);
                        m1.setColor(MarbleColor.HINTED);
                        m1.setDirection(Directions.BOTTOM_RIGHT);
                    }
                }
            }
//            else if (canMoveBottomLeft(chosen_marbles, selected)) {
//                for (Marble m1 : chosen_marbles) {
//                    m1.setImageIcon(ArrowBottomLeft);
//                    m1.setColor(MarbleColor.HINTED);
//                    m1.setDirection(Directions.BOTTOM_LEFT);
//                }
//            }
            else if (m.getCol() + 1 == selected.getCol() && m.getRow() == selected.getRow() - 1 && m.getColor() == MarbleColor.GREEN
                    && selected.getColor() == MarbleColor.BROWN) {
                for (Marble m1 : chosen_marbles) {
                    if (m1.getColor() == MarbleColor.GREEN) {
                        m1.setImageIcon(ArrowBottomLeft);
                        m1.setColor(MarbleColor.HINTED);
                    }
                }
            }

        }
    }




    @Override
    public void mouseExited(MouseEvent e) {
        int resizedDiameter = circleDiameter;

        File green1 = new File("images/green.png");
        BufferedImage originalBlack = null;
        try {
            originalBlack = ImageIO.read(green1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        Image resizedBlack = originalBlack.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon Green = new ImageIcon(resizedBlack);
        for (Marble marble : marbles) {
            if (marble.getColor() == MarbleColor.HINTED) {
                marble.setImageIcon(Green);
                marble.setColor(MarbleColor.GREEN);
            }
        }


    }

    public boolean canMoveTopLeft(ArrayList<Marble> pushed_marbles, Marble selected) {
        Marble m = pushed_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
        Marble m2 = pushed_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
        if (m.getCol() != m2.getCol() && m.getRow() > 4 && m2.getRow() > 4) { //במקרה ורוצים להזיז שמאלה למעלה לכיוון הצד
            for (Marble marble : pushed_marbles) {
                if (getTopLeft(marble).getColor() != MarbleColor.BROWN) {
                    return false;
                }
            }
            for (Marble marble : pushed_marbles) {
                if (getTopLeft(marble).equals(selected))
                    return true;
            }
            return false;
        } else if (m.getCol() != m2.getCol() && ((m.getRow() <= 4) || m2.getRow() <= 4) && m.getRow() == m2.getRow()) {// במקרה ורוצים להזיז שמאלה למעלה לכיוון הצד כאשר אחת הגולות בשורה 4
            for (Marble marble : pushed_marbles) {
                if (getTopLeft(marble).getColor() != MarbleColor.BROWN) {
                    return false;
                }
            }
            return (selected.equals(getTopLeft(m2)) || selected.equals(getTopLeft(m))) && selected.getColor() == MarbleColor.BROWN;
        }
        else if (m.getCol() != m2.getCol() && ((m.getRow() <= 4) || m2.getRow() <= 4)) {// במקרה ורוצים להזיז שמאלה למעלה לכיוון הצד כאשר אחת הגולות בשורה 4
            return (selected.equals(getTopLeft(m2)) || selected.equals(getTopLeft(m))) && selected.getColor() == MarbleColor.BROWN;
        }
        else if (m.getCol() == m2.getCol() && (m.getRow() >= 4)) {
            m = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            if (getTopLeft(m).getColor() != MarbleColor.BROWN) {
                return false;
            }
            for (Marble marble : pushed_marbles) {
                if (getTopLeft(marble).equals(selected))
                    return true;
            }
            return false;
        } else if (m.getCol() == m2.getCol() && (m.getRow() <= 4)) {
            for (Marble marble : pushed_marbles) {
                if (getTopLeft(marble).getColor() != MarbleColor.BROWN) {
                    return false;
                }
            }
            for (Marble marble : pushed_marbles) {
                if (getTopLeft(marble).equals(selected))
                    return true;
            }
            return false;
        } else {
            m = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            if (m.getRow() == 4)
                return m.getCol() == 1 + selected.getCol() && m.getRow() - 1 == selected.getRow() && m.getColor() == MarbleColor.GREEN
                        && (selected.getColor() == MarbleColor.BROWN || selected.getColor() == MarbleColor.WHITE);
            else
                return m.getCol() == selected.getCol() && m.getRow() - 1 == selected.getRow() && m.getColor() == MarbleColor.GREEN
                        && (selected.getColor() == MarbleColor.BROWN || selected.getColor() == MarbleColor.WHITE);
        }
    }

//    public boolean canMoveTopRight(ArrayList<Marble> pushed_marbles, Marble selected){
//        Marble m = pushed_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
//        Marble m2 = pushed_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
//        if (m.getCol() != m2.getCol() && m.getRow() > 4 && m2.getRow() > 4) { //במקרה ורוצים להזיז שמאלה למעלה לכיוון הצד
//            for (Marble marble : pushed_marbles) {
//                if (getTopRight(marble).getColor() != MarbleColor.BROWN) {
//                    return false;
//                }
//            }
//            for (Marble marble : pushed_marbles) {
//                if (getTopRight(marble).equals(selected))
//                    return true;
//            }
//            return false;
//        } else if (m.getCol() != m2.getCol() && ((m.getRow() <= 4) || m2.getRow() <= 4) && m.getRow() == m2.getRow()) {// במקרה ורוצים להזיז שמאלה למעלה לכיוון הצד כאשר אחת הגולות בשורה 4
//            for (Marble marble : pushed_marbles) {
//                if (getTopRight(marble).getColor() != MarbleColor.BROWN) {
//                    return false;
//                }
//            }
//            return (selected.equals(getTopRight(m2)) || selected.equals(getTopRight(m))) && selected.getColor() == MarbleColor.BROWN;
//        }
//        else if (m.getCol() != m2.getCol() && ((m.getRow() <= 4) || m2.getRow() <= 4)) {// במקרה ורוצים להזיז שמאלה למעלה לכיוון הצד כאשר אחת הגולות בשורה 4
//            return (selected.equals(getTopRight(m2)) || selected.equals(getTopRight(m))) && selected.getColor() == MarbleColor.BROWN;
//        }
//        else if (m.getCol() == m2.getCol() && (m.getRow() >= 4)) {
//            m = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
//            if (getTopRight(m).getColor() != MarbleColor.BROWN) {
//                return false;
//            }
//            for (Marble marble : pushed_marbles) {
//                if (getTopRight(marble).equals(selected))
//                    return true;
//            }
//            return false;// צריך להוסיף תנאי שאם העמודות שוות אז M שווה לשורה המינמלית
//        } else if (m.getCol() == m2.getCol() && (m.getRow() <= 4)) {
//            for (Marble marble : pushed_marbles) {
//                if (getTopRight(marble).getColor() != MarbleColor.BROWN) {
//                    return false;
//                }
//            }
//            for (Marble marble : pushed_marbles) {
//                if (getTopRight(marble).equals(selected))
//                    return true;
//            }
//            return false;
//        } else {
//            m = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
//            if (m.getRow() == 4)
//                return m.getCol() == 1 + selected.getCol() && m.getRow() - 1 == selected.getRow() && m.getColor() == MarbleColor.GREEN
//                        && (selected.getColor() == MarbleColor.BROWN || selected.getColor() == MarbleColor.WHITE);
//            else
//                return m.getCol() == selected.getCol() && m.getRow() - 1 == selected.getRow() && m.getColor() == MarbleColor.GREEN
//                        && (selected.getColor() == MarbleColor.BROWN || selected.getColor() == MarbleColor.WHITE);
//        }
//    }


    public boolean canMoveTopRight(ArrayList<Marble> pushed_marbles, Marble selected) {
        Marble m = pushed_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
        Marble m2 = pushed_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
        if (m.getCol() == m2.getCol() && m.getRow() > 4 && m2.getRow() > 4) {
            for (Marble marble : pushed_marbles) {
                if (getTopRight(marble).getColor() != MarbleColor.BROWN) {
                    return false;
                }
            }
            for (Marble marble : pushed_marbles) {
                if (getTopRight(marble).equals(selected))
                    return true;
            }
            return false;

        } else if(m.getRow() == m2.getRow())
        {
            for (Marble marble : pushed_marbles) {
                if (getTopRight(marble).getColor() != MarbleColor.BROWN) {
                    return false;
                }
            }
            for (Marble marble : pushed_marbles) {
                if (getTopRight(marble).equals(selected))
                    return true;
            }
            return false;
        }
        else if (m.getCol() != m2.getCol() && ((m.getRow() <= 4) || m2.getRow() <= 4)) { // במקרה ורוצים להזיז ימינה למעלה לכיוון הצד כאשר אחת הגולות בשורה 4
            return (selected.equals(getTopRight(m2)) || selected.equals(getTopRight(m))) && selected.getColor() == MarbleColor.BROWN;
        } else if (m.getCol() != m2.getCol() && (m.getRow() < 4)) {
            return selected.equals(getTopRight(m)) && selected.getColor() == MarbleColor.BROWN;
        } else if (m.getCol() == m2.getCol() && (m.getRow() <= 4)) {
            for (Marble marble : pushed_marbles) {
                if (getTopRight(marble).getColor() != MarbleColor.BROWN) {
                    return false;
                }
            }
            for (Marble marble : pushed_marbles) {
                if (getTopRight(marble).equals(selected))
                    return true;
            }
            return false;
        } else {
            m = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            if (m.getRow() == 4)
                return m.getCol() == selected.getCol() && m.getRow() - 1 == selected.getRow() && m.getColor() == MarbleColor.GREEN
                        && (selected.getColor() == MarbleColor.BROWN || selected.getColor() == MarbleColor.WHITE);
            return m.getCol() + 1 == selected.getCol() && m.getRow() - 1 == selected.getRow() && m.getColor() == MarbleColor.GREEN
                    && selected.getColor() == MarbleColor.BROWN && selected.getCol() - m2.getCol() == pushed_marbles.size();
        }
    }

    public boolean canMoveLeft(ArrayList<Marble> pushed_marbles, Marble selected) {
        Marble m1 = pushed_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
        Marble m2 = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
        if (m1.getRow() == m2.getRow()) {
            int count = 0;
            for (Marble m : pushed_marbles) {
                if (m.getCol() - selected.getCol() >= 0 && m.getCol() - selected.getCol() <= pushed_marbles.size() && m.getRow() == selected.getRow() && m.getColor() == MarbleColor.GREEN
                        && selected.getColor() == MarbleColor.BROWN)
                    count++;
                else
                    count--;
            }
            return count == pushed_marbles.size();
        } else {
            boolean found = false;
            for (Marble m : pushed_marbles) {
                if (getLeft(m).getColor() != MarbleColor.BROWN)
                    return false;
                if (selected.equals(getLeft(m)))
                    found = true;
            }

            return found;
        }
    }

    public boolean canMoveRight(ArrayList<Marble> pushed_marbles, Marble selected) {
        Marble m1 = pushed_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
        Marble m2 = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
        if (m1.getRow() == m2.getRow()) {
            int count = 0;
            for (Marble m : pushed_marbles) {
                if (m.getCol() - selected.getCol() >= -pushed_marbles.size() && (m.getCol() - selected.getCol()) <= 0 && m.getRow() == selected.getRow()
                        && m.getColor() == MarbleColor.GREEN
                        && selected.getColor() == MarbleColor.BROWN)
                    count++;
                else
                    count--;
            }
            return count == pushed_marbles.size();
        } else {
            boolean found = false;
            for (Marble m : pushed_marbles) {
                if (getRight(m).getColor() != MarbleColor.BROWN)
                    return false;
                if (selected.equals(getRight(m)))
                    found = true;
            }

            return found;
        }
    }

    public boolean canMoveBottomRight(ArrayList<Marble> pushed_marbles, Marble selected) {
        Marble m = pushed_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
        Marble m2 = pushed_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
        if (m.getCol() == m2.getCol() && m.getRow() > 4 && m2.getRow() > 4) {
            Marble minRow = pushed_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            return getBottomRight(minRow).equals(selected);
        } else if (m.getCol() != m2.getCol() && ((m.getRow() <= 4) || m2.getRow() <= 4)) { // במקרה ורוצים להזיז ימינה למעלה לכיוון הצד כאשר אחת הגולות בשורה 4
            return (selected.equals(getBottomRight(m2)) || selected.equals(getBottomRight(m))) && selected.getColor() == MarbleColor.BROWN;
        } else if (m.getCol() != m2.getCol() && (m.getRow() < 4)) {
            return selected.equals(getBottomRight(m)) && selected.getColor() == MarbleColor.BROWN;
        } else if (m.getCol() == m2.getCol() && (m.getRow() <= 4)) {
            for (Marble marble : pushed_marbles) {
                if (getBottomRight(marble).getColor() != MarbleColor.BROWN) {
                    return false;
                }
            }
            for (Marble marble : pushed_marbles) {
                if (getBottomRight(marble).equals(selected))
                    return true;
            }
            return false;
        } else if(m.getCol() != m2.getCol() && m.getRow() > 4 && m2.getRow() > 4)
        {
            for (Marble marble : pushed_marbles) {
                if (getBottomRight(marble).getColor() != MarbleColor.BROWN) {
                    return false;
                }
            }
            for (Marble marble : pushed_marbles) {
                if (getBottomRight(marble).equals(selected))
                    return true;
            }
            return false;
        }
        else {
            m = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            if (m.getRow() == 4)
                return m.getCol() == selected.getCol() && m.getRow() - 1 == selected.getRow() && m.getColor() == MarbleColor.GREEN
                        && (selected.getColor() == MarbleColor.BROWN || selected.getColor() == MarbleColor.WHITE);
            return m.getCol() + 1 == selected.getCol() && m.getRow() - 1 == selected.getRow() && m.getColor() == MarbleColor.GREEN
                    && selected.getColor() == MarbleColor.BROWN && selected.getCol() - m2.getCol() == pushed_marbles.size();
        }
    }

//    private boolean canMoveBottomLeft(ArrayList<Marble> chosen_marbles, Marble selected) {
//        return true;
//    }

    public Marble getRight(Marble marble) {
        for (Marble m : marbles) {
            if (m.getRow() == marble.getRow() && m.getCol() - 1 == marble.getCol())
                return m;
        }
        return new Marble(null, 999, 999, null);
    }

    public Marble getLeft(Marble marble) {
        for (Marble m : marbles) {
            if (m.getRow() == marble.getRow() && m.getCol() + 1 == marble.getCol())
                return m;
        }
        return new Marble(null, 999, 999, null);
    }

    public Marble getTopRight(Marble marble) {
        if (marble.getRow() > 4) {
            for (Marble m : marbles) {
                if (m.getRow() + 1 == marble.getRow() && m.getCol() - 1 == marble.getCol())
                    return m;
            }
        } else {
            for (Marble m : marbles)
                if (m.getRow() + 1 == marble.getRow() && m.getCol() == marble.getCol())
                    return m;
        }
        return new Marble(null, 999, 999, null);
    }

    public Marble getTopLeft(Marble marble) {
        if (marble.getRow() > 4) {
            for (Marble m : marbles)
                if (m.getRow() + 1 == marble.getRow() && m.getCol() == marble.getCol())
                    return m;
        } else
            for (Marble m : marbles)
                if (m.getRow() + 1 == marble.getRow() && m.getCol() + 1 == marble.getCol())
                    return m;

        return new Marble(null, 999, 999, null);
    }

    public Marble getBottomRight(Marble marble) {
        if (marble.getRow() >= 4) {
            for (Marble m : marbles) {
                if (m.getRow() - 1 == marble.getRow() && m.getCol() == marble.getCol())
                    return m;
            }
        } else {
            for (Marble m : marbles)
                if (m.getRow() - 1 == marble.getRow() && m.getCol() - 1 == marble.getCol())
                    return m;
        }
        return new Marble(null, 999, 999, null);
    }

    public Marble getBottomLeft(Marble marble) {
        if (marble.getRow() >= 4) {
            for (Marble m : marbles) {
                if (m.getRow() - 1 == marble.getRow() && m.getCol() - 1 == marble.getCol())
                    return m;
            }
        } else {
            for (Marble m : marbles)
                if (m.getRow() - 1 == marble.getRow() && m.getCol() == marble.getCol())
                    return m;
        }
        return new Marble(null, 999, 999, null);
    }
}

