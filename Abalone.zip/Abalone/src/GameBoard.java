import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;

public class GameBoard extends JFrame implements MouseListener, MouseMotionListener {
    private final int numRows = 9; // Number of rows in the hexagon
    private final int numCols = 5; // Number of columns in the hexagon
    private final int circleDiameter = 50; // Diameter of each circle
    private final int circleSpacing = 20; // Spacing between circles
    private final Color backgroundColor = new Color(224, 206, 158); // Background color of the board
    private List<Marble> marbles;

    private ArrayList<Marble> pushed_marbles = new ArrayList<>();

    private GameState gameState = GameState.CHOOSE;
    private static int GreenCount = 0;

    public GameBoard() throws IOException {
        setTitle("Abalone Game Board");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 800);
        setLocationRelativeTo(null);

        setLayout(null);


        setLocationRelativeTo(null);

        marbles = new ArrayList<>();

        JPanel boardPanel = new JPanel();
        boardPanel.setLayout(null);
        boardPanel.setBackground(backgroundColor);
        boardPanel.setBounds(0, 0, 800, 800);

        File HoleIcon1 = new File("images/brown.png");
        BufferedImage originalImage = ImageIO.read(HoleIcon1);
        int resizedDiameter = circleDiameter;

        // Resize the image
        Image resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon HoleIcon = new ImageIcon(resizedImage);


        File white1 = new File("images/white.jpg");
        BufferedImage originalWhite = ImageIO.read(white1);
        int resizedDiameterColour = 50;

        // Resize the image
        Image resizedWhite = originalWhite.getScaledInstance(resizedDiameterColour, resizedDiameterColour, Image.SCALE_SMOOTH);
        ImageIcon White = new ImageIcon(resizedWhite);

        File black1 = new File("images/Black.png");
        BufferedImage originalBlack = ImageIO.read(black1);

        // Resize the image
        Image resizedBlack = originalBlack.getScaledInstance(resizedDiameterColour, resizedDiameterColour, Image.SCALE_SMOOTH);
        ImageIcon Black = new ImageIcon(resizedBlack);

        // Calculate the center of the panel
        int centerX = getWidth() / 2;
        int centerY = getHeight() / 2;


        // Draw the hexagonal grid of spaces
        for (int row = 0; row < numRows; row++) {
            int numSpaces = 4 + numCols - Math.min(numCols - 1, Math.abs(row - numRows / 2));
            int y = centerY - ((numRows / 2 - row) * (circleDiameter + circleSpacing) + circleDiameter);
            int x = centerX - ((numSpaces - 1) * (circleDiameter + circleSpacing) / 2);
            for (int col = 0; col < numSpaces; col++) {
                if (row < 2 || (row == 2 && (col > 1 && col < 5))) {
                    Marble marble = new Marble(White, row, col, MarbleColor.WHITE);
                    marble.setBounds(x, y, White.getIconWidth(), White.getIconHeight());
                    marble.addMouseListener(this);
                    marbles.add(marble);
                    boardPanel.add(marble);
                    marble.setOpaque(false);
                    x += circleDiameter + circleSpacing;
                } else if (row > 6 || (row == 6 && (col > 1 && col < 5))) {
                    Marble marble = new Marble(Black, row, col, MarbleColor.BLACK);
                    marble.setBounds(x, y, Black.getIconWidth(), Black.getIconHeight());
                    marble.addMouseListener(this);
                    marbles.add(marble);
                    boardPanel.add(marble);
                    marble.setOpaque(false);
                    x += circleDiameter + circleSpacing;
                } else {
                    Marble marble = new Marble(HoleIcon, row, col, MarbleColor.BROWN);
                    marble.setBounds(x, y, HoleIcon.getIconWidth(), HoleIcon.getIconHeight());
                    marble.addMouseListener(this);
                    marbles.add(marble);
                    boardPanel.add(marble);
                    marble.setOpaque(false);
                    x += circleDiameter + circleSpacing;
                }
            }
        }
        add(boardPanel);
        setVisible(true);
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    GameBoard gameBoard = new GameBoard();
                    gameBoard.setVisible(true);
                    //colour_marbles(gameBoard);

                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        Component component = getContentPane().getComponentAt(x, y);
        File Green1 = new File("images/green.png");
        BufferedImage originalImage = null;
        try {
            originalImage = ImageIO.read(Green1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        int resizedDiameter = circleDiameter;

        // Resize the image
        Image resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon Green = new ImageIcon(resizedImage);


        File black1 = new File("images/Black.png");
        BufferedImage originalBlack = null;
        try {
            originalBlack = ImageIO.read(black1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        Image resizedBlack = originalBlack.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon Black = new ImageIcon(resizedBlack);


        File Brown1 = new File("images/brown.png");
        try {
            originalImage = ImageIO.read(Brown1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon Brown = new ImageIcon(resizedImage);

        for (Marble marble : marbles) {
            if (e.getSource() == marble) {
                System.out.println("col: " + marble.getCol());
                System.out.println("row: " + marble.getRow());
                if (marble.getColor() == MarbleColor.BLACK) {
                    System.out.println("hi");
                    if (GreenCount == 3) {
                        for (Marble marble2 : pushed_marbles) {
                            if ((marble2.getColor() == MarbleColor.GREEN || marble2.getColor() == MarbleColor.HINTED) && e.getSource() != marble2) {
                                marble2.setImageIcon(Black);
                                marble2.setColor(MarbleColor.BLACK);
                            }
                        }
                        pushed_marbles = new ArrayList<>();
                        GreenCount = 0;
                    }
                    if (pushed_marbles.size() > 0) {
                        if (!isNext(pushed_marbles, marble) && !isLeftSlant(pushed_marbles, marble) && !isRightSlant(pushed_marbles, marble) && !(marble.isNearList(pushed_marbles)))
                            return;
                    }
                    marble.setImageIcon(Green);
                    marble.setColor(MarbleColor.GREEN);
                    pushed_marbles.add(marble);
                    System.out.println("Size:" + pushed_marbles.size());
                    GreenCount++;
                    System.out.println("Greens:" + GreenCount);

                } else if (marble.getColor() == MarbleColor.GREEN || marble.getColor() == MarbleColor.HINTED) {
                    for (Marble mar : pushed_marbles) {
                        mar.setImageIcon(Black);
                        mar.setColor(MarbleColor.BLACK);
                    }
                    GreenCount = 0;
                    pushed_marbles = new ArrayList<>();
                } else if (marble.getColor() == MarbleColor.BROWN) {
                    if (pushed_marbles.size() > 0) {
                        moveMarbles(Black, Brown);
                    }
                } else if (marble.getColor() == MarbleColor.WHITE) {

                }
            }
            gameState = GameState.SELECTED;
        }
    }

    private void moveMarbles(ImageIcon Black, ImageIcon Brown) {
        if (pushed_marbles.get(0).getDirection() == Directions.TOP_LEFT) {
            Marble m = pushed_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
            Marble m2 = pushed_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
            if ((m.getCol() != m2.getCol() && m.getRow() > 4 && m2.getRow() > 4) || (m.getCol() == m2.getCol() && m.getRow() <= 4 && m2.getRow() <= 4) ||(m.getCol() != m2.getCol() && ((m.getRow() <= 4) || m2.getRow() <= 4))){
                for (Marble marble : pushed_marbles) {
                    getTopLeft(marble).setColor(MarbleColor.BLACK);
                    getTopLeft(marble).setImageIcon(Black);
                    marble.setImageIcon(Brown);
                    marble.setColor(MarbleColor.BROWN);
                }
            }
            else {
                m = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                m2 = pushed_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);

                getTopLeft(m).setImageIcon(Black);
                getTopLeft(m).setColor(MarbleColor.BLACK);
                for (Marble mar : pushed_marbles) {
                    mar.setColor(MarbleColor.BLACK);
                    mar.setImageIcon(Black);
                }
                m2.setColor(MarbleColor.BROWN);
                m2.setImageIcon(Brown);
            }
            pushed_marbles = new ArrayList<>();
            GreenCount = 0;
        } else if (pushed_marbles.get(0).getDirection() == Directions.TOP_RIGHT) {
            Marble m = pushed_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
            Marble m2 = pushed_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
            if (m.getCol() == m2.getCol()) {
                for (Marble marble : pushed_marbles) {
                    getTopRight(marble).setColor(MarbleColor.BLACK);
                    getTopRight(marble).setImageIcon(Black);
                    marble.setImageIcon(Brown);
                    marble.setColor(MarbleColor.BROWN);
                }
            } else {
                m = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
                m2 = pushed_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);

                getTopRight(m).setImageIcon(Black);
                getTopRight(m).setColor(MarbleColor.BLACK);
                for (Marble mar : pushed_marbles) {
                    mar.setColor(MarbleColor.BLACK);
                    mar.setImageIcon(Black);
                }
                m2.setColor(MarbleColor.BROWN);
                m2.setImageIcon(Brown);
            }
            pushed_marbles = new ArrayList<>();
            GreenCount = 0;
        }
        else if (pushed_marbles.get(0).getDirection() == Directions.LEFT) {
            Marble m = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            Marble m2 = pushed_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            if (m.getRow() != m2.getRow()) {
                for (Marble marble : pushed_marbles) {
                    getLeft(marble).setColor(MarbleColor.BLACK);
                    getLeft(marble).setImageIcon(Black);
                    marble.setImageIcon(Brown);
                    marble.setColor(MarbleColor.BROWN);
                }
            } else {
                m = pushed_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
                m2 = pushed_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
                getLeft(m).setImageIcon(Black);
                getLeft(m).setColor(MarbleColor.BLACK);
                for (Marble mar : pushed_marbles) {
                    mar.setColor(MarbleColor.BLACK);
                    mar.setImageIcon(Black);
                }
                m2.setColor(MarbleColor.BROWN);
                m2.setImageIcon(Brown);
            }
            pushed_marbles = new ArrayList<>();
            GreenCount = 0;

        }
        else if (pushed_marbles.get(0).getDirection() == Directions.RIGHT) {
            Marble m = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            Marble m2 = pushed_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            if (m.getRow() != m2.getRow()) {
                for (Marble marble : pushed_marbles) {
                    getRight(marble).setColor(MarbleColor.BLACK);
                    getRight(marble).setImageIcon(Black);
                    marble.setImageIcon(Brown);
                    marble.setColor(MarbleColor.BROWN);
                }
            } else {
                m = pushed_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
                m2 = pushed_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
                getRight(m2).setImageIcon(Black);
                getRight(m2).setColor(MarbleColor.BLACK);
                for (Marble mar : pushed_marbles) {
                    mar.setColor(MarbleColor.BLACK);
                    mar.setImageIcon(Black);
                }
                m.setColor(MarbleColor.BROWN);
                m.setImageIcon(Brown);
            }
            pushed_marbles = new ArrayList<>();
            GreenCount = 0;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // put arrow on selected marbles

        BufferedImage originalImage = null;
        int resizedDiameter = circleDiameter;
        Image resizedImage = null;

        File ArrowTopRight1 = new File("images/arrowrightup.png");
        try {
            originalImage = ImageIO.read(ArrowTopRight1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon ArrowTopRight = new ImageIcon(resizedImage);

        File ArrowRight1 = new File("images/arrowright.png");
        try {
            originalImage = ImageIO.read(ArrowRight1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon ArrowRight = new ImageIcon(resizedImage);

        File ArrowBottomRight1 = new File("images/arrowrightdown.png");
        try {
            originalImage = ImageIO.read(ArrowBottomRight1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon ArrowBottomRight = new ImageIcon(resizedImage);

        File ArrowTopLeft1 = new File("images/arrowleftup.png");
        try {
            originalImage = ImageIO.read(ArrowTopLeft1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon ArrowTopLeft = new ImageIcon(resizedImage);

        File ArrowLeft1 = new File("images/arrowleft.png");
        try {
            originalImage = ImageIO.read(ArrowLeft1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon ArrowLeft = new ImageIcon(resizedImage);

        File ArrowBottomLeft1 = new File("images/arrowBottomLeft.png");
        try {
            originalImage = ImageIO.read(ArrowBottomLeft1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        resizedImage = originalImage.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon ArrowBottomLeft = new ImageIcon(resizedImage);

        Marble selected = null;
        for (Marble m : marbles) {
            if (m == e.getSource())
                selected = new Marble(m);
        }

        for (Marble m : pushed_marbles) {
            assert selected != null;
            if (selected.getColor() != MarbleColor.BLACK && selected.getColor() != MarbleColor.GREEN && selected.getColor() != MarbleColor.HINTED) {

                if (canMoveTopRight(pushed_marbles, selected)) {
                    for (Marble m1 : pushed_marbles) {
                        m1.setImageIcon(ArrowTopRight);
                        m1.setColor(MarbleColor.HINTED);
                        m1.setDirection(Directions.TOP_RIGHT);

                    }
                } else if (canMoveTopLeft(pushed_marbles, selected)) {
                    for (Marble m1 : pushed_marbles) {
                        m1.setImageIcon(ArrowTopLeft);
                        m1.setColor(MarbleColor.HINTED);
                        m1.setDirection(Directions.TOP_LEFT);

                    }
                } else if (canMoveRight(pushed_marbles, selected)) {
                    for (Marble m1 : pushed_marbles) {
                        m1.setImageIcon(ArrowRight);
                        m1.setColor(MarbleColor.HINTED);
                        m1.setDirection(Directions.RIGHT);

                    }
                } else if (canMoveLeft(pushed_marbles, selected)) {
                    for (Marble m1 : pushed_marbles) {
                        m1.setImageIcon(ArrowLeft);
                        m1.setColor(MarbleColor.HINTED);
                        m1.setDirection(Directions.LEFT);

                    }
                } else if (m.getCol() + 1 == selected.getCol() && m.getRow() + 1 == selected.getRow() && m.getColor() == MarbleColor.GREEN
                        && selected.getColor() == MarbleColor.BROWN) {
                    for (Marble m1 : pushed_marbles) {
                        if (m1.getColor() == MarbleColor.GREEN) {
                            m1.setImageIcon(ArrowBottomRight);
                            m1.setColor(MarbleColor.HINTED);
                        }
                    }
                } else if (m.getCol() + 1 == selected.getCol() && m.getRow() == selected.getRow() - 1 && m.getColor() == MarbleColor.GREEN
                        && selected.getColor() == MarbleColor.BROWN) {
                    for (Marble m1 : pushed_marbles) {
                        if (m1.getColor() == MarbleColor.GREEN) {
                            m1.setImageIcon(ArrowBottomLeft);
                            m1.setColor(MarbleColor.HINTED);
                        }
                    }
                }

            }
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
        int resizedDiameter = circleDiameter;

        File green1 = new File("images/green.png");
        BufferedImage originalBlack = null;
        try {
            originalBlack = ImageIO.read(green1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        // Resize the image
        Image resizedBlack = originalBlack.getScaledInstance(resizedDiameter, resizedDiameter, Image.SCALE_SMOOTH);
        ImageIcon Green = new ImageIcon(resizedBlack);
        for (Marble marble : marbles) {
            if (marble.getColor() == MarbleColor.HINTED) {
                marble.setImageIcon(Green);
                marble.setColor(MarbleColor.GREEN);
            }
        }


    }

    @Override
    public void mouseDragged(MouseEvent e) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {
        for (Marble marble : marbles) {
            if (marble.getColor() == MarbleColor.GREEN) {
                int mouseX = e.getX();
                int mouseY = e.getY();
                int marbleX = marble.getX() + marble.getWidth() / 2;
                int marbleY = marble.getY() + marble.getHeight() / 2;
                double angle = Math.atan2(mouseY - marbleY, mouseX - marbleX);
                ImageIcon rotatedIcon = rotateImage(marble.getImageIcon(), angle);
                marble.setImageIcon(rotatedIcon);
            }
        }
    }

    private ImageIcon rotateImage(ImageIcon icon, double angle) {
        int w = icon.getIconWidth();
        int h = icon.getIconHeight();
        BufferedImage rotatedImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = rotatedImage.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.rotate(angle, w / 2, h / 2);
        g2.drawImage(icon.getImage(), 0, 0, null);
        g2.dispose();
        return new ImageIcon(rotatedImage);
    }

    public boolean isNext(ArrayList<Marble> pushed_marbles, Marble marble2) {
        int count = 0;
        for (Marble marble1 : pushed_marbles) {
            if (marble1.getRow() == marble2.getRow() && Math.abs(marble1.getCol() - marble2.getCol()) <= 2) {
                count++;
            }
        }
        return count == pushed_marbles.size();
    }

    public boolean isRightSlant(ArrayList<Marble> pushed_marbles, Marble marble2) {
        for (Marble marble1 : pushed_marbles) {
            if (Math.abs(marble1.getRow() - marble2.getRow()) == 1 && marble1.getCol() == marble2.getCol()) {
                return true;
            }
        }
        return false;
    }

    public boolean isLeftSlant(ArrayList<Marble> pushed_marbles, Marble marble2) {
        for (Marble marble1 : pushed_marbles) {
            if ((Math.abs(marble1.getRow() - marble2.getRow()) == 1 && Math.abs(marble1.getCol() - marble2.getCol()) == 1)) {
                return true;
            }
        }
        return false;
    }

    public boolean canMoveTopLeft(ArrayList<Marble> pushed_marbles, Marble selected) {
        Marble m = pushed_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
        Marble m2 = pushed_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
        if (m.getCol() != m2.getCol() && m.getRow() > 4 && m2.getRow() > 4) { //במקרה ורוצים להזיז שמאלה למעלה לכיוון הצד
            for (Marble marble : pushed_marbles) {
                if (getTopLeft(marble).getColor() != MarbleColor.BROWN) {
                    return false;
                }
            }
            for (Marble marble : pushed_marbles) {
                if (getTopLeft(marble).equals(selected))
                    return true;
            }
            return false;
        } else if (m.getCol() != m2.getCol() && ((m.getRow() <= 4) || m2.getRow() <= 4)) { // במקרה ורוצים להזיז שמאלה למעלה לכיוון הצד כאשר אחת הגולות בשורה 4
            System.out.println("lolooolol");
            return selected.equals(getTopLeft(m2)) && selected.getColor() == MarbleColor.BROWN;
        } else if (m.getCol() == m2.getCol() && (m.getRow() > 4)) {
            m = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            if (getTopLeft(m).getColor() != MarbleColor.BROWN) {
                return false;
            }
            for (Marble marble : pushed_marbles) {
                if (getTopLeft(marble).equals(selected))
                    return true;
            }
            return false;
        } else if(m.getCol() == m2.getCol() && (m.getRow() <= 4)){
            for (Marble marble:pushed_marbles) {
                if (getTopLeft(marble).getColor() != MarbleColor.BROWN) {
                    return false;
                }
            }
            for (Marble marble : pushed_marbles) {
                if (getTopLeft(marble).equals(selected))
                    return true;
            }
            return false;
        }
        else {
            m = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            if (m.getRow() == 4)
                return m.getCol() == 1 + selected.getCol() && m.getRow() - 1 == selected.getRow() && m.getColor() == MarbleColor.GREEN
                        && (selected.getColor() == MarbleColor.BROWN || selected.getColor() == MarbleColor.WHITE);
            else
                return m.getCol() == selected.getCol() && m.getRow() - 1 == selected.getRow() && m.getColor() == MarbleColor.GREEN
                        && (selected.getColor() == MarbleColor.BROWN || selected.getColor() == MarbleColor.WHITE);
        }
    }

    public boolean canMoveTopRight(ArrayList<Marble> pushed_marbles, Marble selected) {
        Marble m = pushed_marbles.stream().max(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
        Marble m2 = pushed_marbles.stream().min(Comparator.comparing(Marble::getCol)).orElseThrow(NoSuchElementException::new);
        if (m.getCol() == m2.getCol() && m.getRow() > 4 && m2.getRow() > 4) {
            for (Marble marble : pushed_marbles) {
                if (getTopRight(marble).getColor() != MarbleColor.BROWN) {
                    return false;
                }
            }
            for (Marble marble : pushed_marbles) {
                if (getTopRight(marble).equals(selected))
                    return true;
            }
            return false;

        } else if (m.getCol() != m2.getCol() && (m.getRow() < 4)) {
            System.out.println("hey");
            return selected.equals(getTopRight(m)) && selected.getColor() == MarbleColor.BROWN;
        } else {
            m = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
            if (m.getRow() == 4)
                return m.getCol() == selected.getCol() && m.getRow() - 1 == selected.getRow() && m.getColor() == MarbleColor.GREEN
                        && (selected.getColor() == MarbleColor.BROWN || selected.getColor() == MarbleColor.WHITE);
            return m.getCol() + 1 == selected.getCol() && m.getRow() - 1 == selected.getRow() && m.getColor() == MarbleColor.GREEN
                    && selected.getColor() == MarbleColor.BROWN && selected.getCol() - m2.getCol() == pushed_marbles.size();
        }
    }

    public boolean canMoveLeft(ArrayList<Marble> pushed_marbles, Marble selected) {
        Marble m1 = pushed_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
        Marble m2 = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
        if (m1.getRow() == m2.getRow()) {
            int count = 0;
            for (Marble m : pushed_marbles) {
                if (m.getCol() - selected.getCol() >= 0 && m.getCol() - selected.getCol() <= pushed_marbles.size() && m.getRow() == selected.getRow() && m.getColor() == MarbleColor.GREEN
                        && selected.getColor() == MarbleColor.BROWN)
                    count++;
                else
                    count--;
            }
            return count == pushed_marbles.size();
        } else {
            boolean found = false;
            for (Marble m : pushed_marbles) {
                if (getLeft(m).getColor() != MarbleColor.BROWN)
                    return false;
                if (selected.equals(getLeft(m)))
                    found = true;
            }

            return found;
        }
    }

    public boolean canMoveRight(ArrayList<Marble> pushed_marbles, Marble selected) {
        Marble m1 = pushed_marbles.stream().max(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
        Marble m2 = pushed_marbles.stream().min(Comparator.comparing(Marble::getRow)).orElseThrow(NoSuchElementException::new);
        if (m1.getRow() == m2.getRow()) {
            int count = 0;
            for (Marble m : pushed_marbles) {
                if (m.getCol() - selected.getCol() >= -pushed_marbles.size() && (m.getCol() - selected.getCol()) <= 0 && m.getRow() == selected.getRow()
                        && m.getColor() == MarbleColor.GREEN
                        && selected.getColor() == MarbleColor.BROWN)
                    count++;
                else
                    count--;
            }
            return count == pushed_marbles.size();
        } else {
            boolean found = false;
            for (Marble m : pushed_marbles) {
                if (getRight(m).getColor() != MarbleColor.BROWN)
                    return false;
                if (selected.equals(getRight(m)))
                    found = true;
            }

            return found;
        }
    }

    public Marble getRight(Marble marble) {
        for (Marble m : marbles) {
            if (m.getRow() == marble.getRow() && m.getCol() - 1 == marble.getCol())
                return m;
        }
        return new Marble(null, 999, 999, null);
    }

    public Marble getLeft(Marble marble) {
        for (Marble m : marbles) {
            if (m.getRow() == marble.getRow() && m.getCol() + 1 == marble.getCol())
                return m;
        }
        return new Marble(null, 999, 999, null);
    }

    public Marble getTopRight(Marble marble) {
        if (marble.getRow() > 4) {
            for (Marble m : marbles) {
                if (m.getRow() + 1 == marble.getRow() && m.getCol() - 1 == marble.getCol())
                    return m;
            }
        } else {
            for (Marble m : marbles)
                if (m.getRow() + 1 == marble.getRow() && m.getCol() == marble.getCol())
                    return m;
        }
        return new Marble(null, 999, 999, null);
    }

    public Marble getTopLeft(Marble marble) {
        if (marble.getRow() > 4) {
            for (Marble m : marbles)
                if (m.getRow() + 1 == marble.getRow() && m.getCol() == marble.getCol())
                    return m;
        } else
            for (Marble m : marbles)
                if (m.getRow() + 1 == marble.getRow() && m.getCol() + 1 == marble.getCol())
                    return m;

        return new Marble(null, 999, 999, null);
    }
}

